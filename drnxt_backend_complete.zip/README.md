# DRNXT Backend

Basic FastAPI backend for DRNXT platform.