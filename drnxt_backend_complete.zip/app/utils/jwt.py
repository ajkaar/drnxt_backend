# JWT helper (dummy)
def create_token(data):
    return "jwt-token"