# Dummy DB connector
def get_db():
    return None